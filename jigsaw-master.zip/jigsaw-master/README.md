# Jigsaw puzzle generator

https://draradech.github.io/jigsaw/index.html

LICENSE info:

save function: probably **cc-by-sa**  
(the save function is pieced together based on a bunch of answers of this stackoverflow:
https://stackoverflow.com/questions/19327749/javascript-blob-filename-without-link, that
should make that part cc-by-sa - unless the posters there didn't have the rights to post it)

everything else: whatever you want, **cc0** (https://creativecommons.org/publicdomain/zero/1.0/)

if you want to give credit, a link to this repo is fine, but in no way required
